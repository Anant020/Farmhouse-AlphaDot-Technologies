// import React ,{useState,useEffect}from 'react'

// export default function AmenitiesPage() {
//     const [Amenities, setAmenities] = useState(null);

//     useEffect(() => {
//       axios
//       .get(`/alpha-homes/property/getAmenitiesDetails/${id}`)
//       .then((response) => {
//         console.log(response.data);
//         setAmenities(response.data);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//       }
//     },[])
    
//   return (
//     <div>
      
//     </div>
//   )
// }
